---
title: Team
nav:
  order: 3
  tooltip: About our team members
---

# Our Team

We are a diverse, collaborative group of researchers united by our passion for using computational methods to advance biomedical science. Our team includes computer scientists, biologists, mathematicians, and clinicians from around the world.
{:.center}

{% include section.html %}

## Principal Investigator

{%
  include list.html
  data="members"
  component="portrait"
  filters="role: pi"
%}

{:.center}

{% include section.html %}

## Postdoctoral Researchers

Our postdocs lead ambitious research projects while mentoring students and developing independent research programs.

{%
  include list.html
  data="members"
  component="portrait"
  filters="role: postdoc"
%}

{% include section.html %}

## Graduate Students

Our graduate students drive innovation through their creative approaches to challenging problems.

{%
  include list.html
  data="members"
  component="portrait"
  filters="role: phd"
%}

{% include section.html %}

## Research Staff

Our research staff provide essential technical expertise and maintain our computational infrastructure.

{%
  include list.html
  data="members"
  component="portrait"
  filters="role: staff"
%}

{% include section.html %}

## Undergraduate Researchers

Talented undergraduates contribute to cutting-edge research while gaining valuable experience.

{%
  include list.html
  data="members"
  component="portrait"
  filters="role: undergrad"
%}

{% include section.html %}

## Visiting Scholars

We regularly host visiting researchers from institutions worldwide.

{%
  include list.html
  data="members"
  component="portrait"
  filters="role: visitor"
%}

{% include section.html %}

## Alumni

Our alumni have gone on to leadership positions in academia, industry, and healthcare.

### Recent Placements

#### Faculty Positions
- **Dr. Sarah Kim** (PhD 2023) → Assistant Professor, Stanford University
- **Dr. James Liu** (Postdoc 2023) → Assistant Professor, MIT
- **Dr. Maria Garcia** (PhD 2022) → Assistant Professor, UC Berkeley

#### Industry
- **Dr. Alex Chen** (PhD 2023) → Research Scientist, DeepMind
- **Dr. Priya Patel** (Postdoc 2022) → Senior ML Engineer, OpenAI
- **Dr. Tom Anderson** (PhD 2021) → Principal Data Scientist, Genentech

#### Clinical/Healthcare
- **Dr. Emily Brown** (MD/PhD 2023) → Resident, Johns Hopkins Hospital
- **Dr. David Lee** (Postdoc 2022) → Computational Biologist, Memorial Sloan Kettering

{%
  include button.html
  link="alumni"
  text="Full Alumni List"
  icon="fa-solid fa-graduation-cap"
  flip=true
  style="button"
%}
{:.center}

{% include section.html %}

## Lab Culture

### Our Values

**Collaboration Over Competition**
We believe the best science emerges from teamwork. Lab members regularly collaborate on projects, share expertise, and celebrate each other's successes.

**Diversity and Inclusion**
We are committed to creating an inclusive environment where all team members can thrive. We actively recruit from underrepresented groups and maintain a supportive, respectful culture.

**Work-Life Balance**
We recognize that creativity and productivity require rest and renewal. We encourage flexible schedules, support parental leave, and respect boundaries.

**Open Science**
We share our code, data, and methods freely. We believe science advances fastest when knowledge is open to all.

### Lab Activities

- **Weekly Lab Meetings**: Present research, discuss papers, brainstorm ideas
- **Journal Club**: Critical discussion of recent publications
- **Hackathons**: Quarterly coding sprints on collaborative projects
- **Social Events**: Monthly lab dinners, holiday parties, retreat
- **Professional Development**: Grant writing workshops, presentation training
- **Mentorship Program**: Structured mentoring for all trainees

{% include section.html %}

## Diversity Statement

We believe that diversity drives innovation. Our lab actively works to create an inclusive environment where researchers from all backgrounds can succeed. We are committed to:

- Recruiting and retaining researchers from underrepresented groups
- Creating mentorship opportunities for first-generation college students
- Partnering with HBCUs and minority-serving institutions
- Supporting family-friendly policies and flexible work arrangements
- Fostering a culture of respect, empathy, and mutual support

{% include section.html %}

## Join Us

We're always looking for passionate researchers at all levels. We offer:

- Competitive salaries and benefits
- Access to state-of-the-art computational resources
- Travel support for conferences
- Professional development opportunities
- Collaborative, supportive environment
- Flexible work arrangements

{%
  include button.html
  link="join"
  text="View Open Positions"
  icon="fa-solid fa-user-plus"
  flip=true
  style="button"
%}
{%
  include button.html
  link="contact"
  text="Get in Touch"
  icon="fa-solid fa-envelope"
  flip=true
  style="button"
%}
{:.center}
