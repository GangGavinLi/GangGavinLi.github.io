---
title: Home
---

# **Computational Biology & AI Lab**

## Decoding Life Through Machine Intelligence
{:.center}

{% include section.html full=true %}

{% capture text %}
We are pioneering the next generation of AI-powered tools for biological discovery. Our mission is to accelerate the translation of complex biological data into actionable medical insights that improve human health worldwide.

{%
  include button.html
  link="research"
  text="Explore Our Research"
  icon="fa-solid fa-arrow-right"
  flip=true
  style="button"
%}
{%
  include button.html
  link="team"
  text="Meet Our Team"
  icon="fa-solid fa-users"
  flip=true
  style="button"
%}
{:.center}
{% endcapture %}

{%
  include feature.html
  image="images/hero-lab.jpg"
  headline="Welcome to the Computational Biology & AI Lab"
  text=text
%}

{% include section.html %}

## Research Areas

Our interdisciplinary research spans the intersection of artificial intelligence, computational biology, and precision medicine. We develop novel computational methods to tackle the most challenging problems in biomedical science.

{% capture text %}
We develop state-of-the-art deep learning architectures for analyzing genomic sequences, predicting variant effects, and understanding gene regulation. Our models have achieved breakthrough performance on multiple genomic prediction tasks.
{% endcapture %}
{%
  include feature.html
  image="images/genomics-ai.jpg"
  title="AI for Genomics"
  text=text
  link="research#genomics"
%}

{% capture text %}
Our lab creates innovative methods for analyzing single-cell data, including trajectory inference, cell type classification, and multi-modal integration. We're mapping cellular diversity across tissues and disease states.
{% endcapture %}
{%
  include feature.html
  image="images/single-cell.jpg"
  title="Single-Cell Analysis"
  text=text
  link="research#single-cell"
  flip=true
%}

{% capture text %}
We build comprehensive molecular networks to understand disease mechanisms and identify therapeutic targets. Our network-based approaches have revealed new drug repurposing opportunities and biomarkers.
{% endcapture %}
{%
  include feature.html
  image="images/network-biology.jpg"
  title="Network Medicine"
  text=text
  link="research#networks"
%}

{% include section.html %}

## Latest Publications

Our research has been published in leading journals including Nature, Science, Cell, and Nature Methods. We are committed to open science and reproducible research.

{%
  include citation.html
  lookup="doi:10.1038/s41586-021-03819-2"
  style="rich"
%}

{%
  include citation.html
  lookup="doi:10.1016/j.cell.2022.04.021"
  style="rich"
%}

{%
  include button.html
  link="research"
  text="View All Publications"
  icon="fa-solid fa-book"
  flip=true
  style="button"
%}
{:.center}

{% include section.html %}

## By the Numbers
{:.center}

{%
  include feature.html
  image="images/icon-publication.svg"
  title="150+"
  text="Peer-reviewed publications"
  link="research"
%}

{%
  include feature.html
  image="images/icon-download.svg"
  title="1M+"
  text="Software downloads"
  link="tools"
%}

{%
  include feature.html
  image="images/icon-citation.svg"
  title="10,000+"
  text="Citations"
  link="research"
%}

{%
  include feature.html
  image="images/icon-grant.svg"
  title="$25M+"
  text="Research funding"
  link="research"
%}

{% include section.html %}

## Recent News

{% capture news1 %}
**November 2024** - Our latest paper on transformer models for genomic prediction is published in Nature Methods. The model achieves state-of-the-art performance on regulatory element prediction.
{% endcapture %}

{% capture news2 %}
**October 2024** - Lab receives $5M NIH grant to develop AI tools for precision oncology. This collaborative project will integrate multi-modal data to predict treatment response.
{% endcapture %}

{% capture news3 %}
**September 2024** - Three lab members win best paper awards at RECOMB 2024. Congratulations to our outstanding researchers!
{% endcapture %}

{%
  include feature.html
  image="images/news-nature.jpg"
  text=news1
%}

{%
  include feature.html
  image="images/news-nih.jpg"
  text=news2
  flip=true
%}

{%
  include feature.html
  image="images/news-award.jpg"
  text=news3
%}

{%
  include button.html
  link="blog"
  text="More News"
  icon="fa-solid fa-newspaper"
  flip=true
  style="button"
%}
{:.center}

{% include section.html %}

## Join Our Team

We're always looking for talented researchers who are passionate about using AI to advance biomedical science. We offer a collaborative environment, cutting-edge resources, and exciting research opportunities.

{%
  include button.html
  link="join"
  text="Open Positions"
  icon="fa-solid fa-door-open"
  flip=true
  style="button"
%}
{%
  include button.html
  link="contact"
  text="Contact Us"
  icon="fa-solid fa-envelope"
  flip=true
  style="button"
%}
{:.center}

{% include section.html %}

## Funding Support

We gratefully acknowledge support from:
{:.center}

{%
  include gallery.html

  image1="images/funding/nih.png"
  tooltip1="National Institutes of Health"

  image2="images/funding/nsf.png"
  tooltip2="National Science Foundation"

  image3="images/funding/czi.png"
  tooltip3="Chan Zuckerberg Initiative"
  
  image4="images/funding/simons.png"
  tooltip4="Simons Foundation"
%}
