# Computational Biology & AI Lab Website

A modern, feature-rich lab website built with the Lab Website Template framework. This website showcases our research in computational biology, machine learning, and their applications to biomedical problems.

![Lab Website](images/screenshot.png)

## 🌟 Features

- **Automatic Citations**: Publications automatically formatted from DOIs
- **Team Profiles**: Detailed member pages with social links
- **Project Showcases**: Software tools and datasets
- **Blog System**: News and updates with tagging
- **Responsive Design**: Looks great on all devices
- **SEO Optimized**: Built-in meta tags and sitemap
- **Fast Loading**: Static site with optimized assets
- **Easy Maintenance**: Simple markdown-based content

## 🚀 Quick Start

### Prerequisites

- Ruby (>= 2.7)
- Bundler (`gem install bundler`)
- Git
- Node.js (optional, for additional tools)

### Local Development

1. **Clone the repository**
```bash
git clone https://github.com/compbioai-lab/lab-website.git
cd lab-website
```

2. **Install dependencies**
```bash
bundle install
```

3. **Run locally**
```bash
bundle exec jekyll serve
```

4. **View the site**
Open [http://localhost:4000](http://localhost:4000) in your browser

### Docker Development (Alternative)

```bash
docker build -t lab-website .
docker run -p 4000:4000 -v $(pwd):/site lab-website
```

## 📁 Project Structure

```
lab-website/
├── _config.yml          # Site configuration
├── index.md            # Homepage
├── _members/           # Team member profiles
│   ├── pi.md
│   ├── postdoc-name.md
│   └── student-name.md
├── _posts/             # Blog posts
│   └── YYYY-MM-DD-title.md
├── _data/              # Data files
│   ├── sources.yaml    # Publications (DOIs)
│   ├── projects.yaml   # Project information
│   └── settings.yaml   # Additional settings
├── images/             # Images and media
├── _includes/          # Reusable components
├── _layouts/           # Page templates
├── _sass/              # Custom styles
├── research.md         # Research page
├── team.md            # Team page
├── tools.md           # Software page
├── blog.md            # Blog page
├── contact.md         # Contact page
└── join.md            # Recruitment page
```

## 🎨 Customization

### Basic Configuration

Edit `_config.yml` to update:

```yaml
title: Your Lab Name
subtitle: Your Tagline
description: Lab description
links:
  email: your-email@university.edu
  github: your-github
  twitter: your-twitter
```

### Adding Team Members

Create a new file in `_members/`:

```markdown
---
name: Jane Doe
image: images/team/jane-doe.jpg
role: postdoc
links:
  email: jane@university.edu
  github: janedoe
---

Biography and research interests here...
```

### Adding Publications

Add DOIs to `_data/sources.yaml`:

```yaml
- id: doi:10.1038/nature12345
  image: images/papers/paper.jpg
  tags:
    - genomics
    - featured
```

### Creating Blog Posts

Add a new file in `_posts/`:

```markdown
---
title: Post Title
author: member-name
tags:
  - news
  - research
---

Post content here...
```

## 🌐 Deployment

### GitHub Pages

1. **Enable GitHub Pages**
   - Go to Settings → Pages
   - Source: Deploy from branch
   - Branch: main (or gh-pages)

2. **Update configuration**
   ```yaml
   # _config.yml
   url: "https://yourusername.github.io"
   baseurl: "/lab-website"
   ```

3. **Push to GitHub**
   ```bash
   git add .
   git commit -m "Initial commit"
   git push origin main
   ```

### Custom Domain

1. Add `CNAME` file with your domain
2. Configure DNS:
   - A record → 185.199.108.153
   - CNAME record → yourusername.github.io

### Netlify (Alternative)

1. Connect GitHub repository
2. Build command: `bundle exec jekyll build`
3. Publish directory: `_site`

## 🧪 Testing

### Local Testing
```bash
# Check for broken links
bundle exec htmlproofer ./_site

# Build for production
JEKYLL_ENV=production bundle exec jekyll build

# Serve with production settings
JEKYLL_ENV=production bundle exec jekyll serve
```

### Continuous Integration

See `.github/workflows/ci.yml` for automated testing

## 📚 Documentation

### Detailed Guides

- [Content Management](docs/content.md)
- [Styling Guide](docs/styling.md)
- [Component Library](docs/components.md)
- [Deployment Options](docs/deployment.md)
- [Performance Tips](docs/performance.md)

### Lab Website Template

This site is built with the [Lab Website Template](https://greene-lab.gitbook.io/lab-website-template-docs/). For detailed documentation:

- [Official Documentation](https://greene-lab.gitbook.io/lab-website-template-docs/)
- [GitHub Repository](https://github.com/greenelab/lab-website-template)
- [Support Forum](https://github.com/greenelab/lab-website-template/discussions)

## 🤝 Contributing

We welcome contributions! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

### How to Contribute

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Submit a pull request

### Updating Content

Lab members can update content directly:
- Use GitHub's web interface for simple edits
- Clone locally for major changes
- Ask @davidkim for help

## 🐛 Troubleshooting

### Common Issues

**Bundle install fails**
```bash
gem update bundler
bundle update
```

**Jekyll serve error**
```bash
bundle exec jekyll clean
bundle install
bundle exec jekyll serve
```

**Port already in use**
```bash
bundle exec jekyll serve --port 4001
```

### Getting Help

- Check [documentation](https://greene-lab.gitbook.io/lab-website-template-docs/)
- Open an [issue](https://github.com/compbioai-lab/lab-website/issues)
- Contact the lab webmaster

## 📊 Analytics

The site includes:
- Google Analytics tracking
- Page view statistics
- User engagement metrics
- Search console integration

## 🔒 Security

- HTTPS enforced
- Regular dependency updates
- No sensitive data in repository
- Secure contact forms

## 📝 License

Content: [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)  
Code: [MIT License](LICENSE)

## 🙏 Acknowledgments

- [Lab Website Template](https://github.com/greenelab/lab-website-template) by Greene Lab
- Icons from [Font Awesome](https://fontawesome.com)
- Hosting by [GitHub Pages](https://pages.github.com)

## 📧 Contact

**Technical Issues**: webmaster@compbioai-lab.org  
**Content Updates**: contact@compbioai-lab.org  
**General Inquiries**: [Contact Page](https://compbioai-lab.org/contact)

---

<p align="center">
  Made with ❤️ by the Computational Biology & AI Lab<br>
  Powered by <a href="https://github.com/greenelab/lab-website-template">Lab Website Template</a>
</p>
