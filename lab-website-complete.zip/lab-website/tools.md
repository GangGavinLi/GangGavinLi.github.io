---
title: Tools
nav:
  order: 2
  tooltip: Software, datasets, and resources
---

# Tools & Resources

All our software is open-source and freely available. We develop user-friendly tools that are well-documented, tested, and maintained. Our tools have been adopted by thousands of researchers worldwide.
{:.center}

{% include section.html %}

## Featured Software

{% capture genomegpt %}
**GenomeGPT** is a suite of transformer-based models for genomic sequence analysis. It can predict gene expression, identify regulatory elements, and analyze the effects of genetic variants with state-of-the-art accuracy.

- 🏆 Nature Methods Tool of the Year 2024
- 📊 10,000+ users worldwide
- 📝 50+ citations
- 🚀 Cloud API available

{%
  include button.html
  text="GitHub"
  link="https://github.com/compbioai-lab/GenomeGPT"
  style="button"
%}
{%
  include button.html
  text="Documentation"
  link="https://genomegpt.readthedocs.io"
  style="button"
%}
{%
  include button.html
  text="Web Server"
  link="https://genomegpt.compbioai-lab.org"
  style="button"
%}
{% endcapture %}

{%
  include feature.html
  image="images/tools/genomegpt.png"
  headline="GenomeGPT"
  text=genomegpt
%}

{% capture scintegrate %}
**scIntegrate** provides cutting-edge methods for integrating single-cell multi-omics data. It supports RNA-seq, ATAC-seq, proteomics, and spatial transcriptomics data, enabling comprehensive cell state analysis.

- 🔬 Handles 10+ data modalities
- 💻 Scalable to millions of cells
- 📊 Interactive visualization
- 🎯 Batch effect correction

{%
  include button.html
  text="GitHub"
  link="https://github.com/compbioai-lab/scIntegrate"
  style="button"
%}
{%
  include button.html
  text="Tutorials"
  link="https://scintegrate.compbioai-lab.org/tutorials"
  style="button"
%}
{%
  include button.html
  text="Paper"
  link="https://doi.org/10.1038/s41592-023-01234-5"
  style="button"
%}
{% endcapture %}

{%
  include feature.html
  image="images/tools/scintegrate.png"
  headline="scIntegrate"
  text=scintegrate
  flip=true
%}

{% include section.html %}

## Software Catalog

### Genomics & Genetics

| Tool | Description | Users | Citations | Links |
|:-----|:------------|:------|:----------|:------|
| **GenomeGPT** | Transformer models for genomics | 10,000+ | 50+ | [GitHub](https://github.com/compbioai-lab/GenomeGPT) \| [Docs](https://genomegpt.readthedocs.io) |
| **VariantNet** | Pathogenic variant prediction | 5,000+ | 30+ | [GitHub](https://github.com/compbioai-lab/VariantNet) \| [Web](https://variantnet.org) |
| **ChromaNet** | 3D chromatin modeling | 2,000+ | 15+ | [GitHub](https://github.com/compbioai-lab/ChromaNet) |
| **CRISPR-ML** | CRISPR guide design | 3,000+ | 25+ | [GitHub](https://github.com/compbioai-lab/CRISPR-ML) |

### Single-Cell Analysis

| Tool | Description | Users | Citations | Links |
|:-----|:------------|:------|:----------|:------|
| **scIntegrate** | Multi-omics integration | 8,000+ | 40+ | [GitHub](https://github.com/compbioai-lab/scIntegrate) |
| **CellTrajectory** | Trajectory inference | 4,000+ | 20+ | [GitHub](https://github.com/compbioai-lab/CellTrajectory) |
| **scVelo-DL** | RNA velocity with deep learning | 3,000+ | 15+ | [GitHub](https://github.com/compbioai-lab/scVelo-DL) |
| **SpatialCell** | Spatial transcriptomics | 2,500+ | 10+ | [GitHub](https://github.com/compbioai-lab/SpatialCell) |

### Drug Discovery & Networks

| Tool | Description | Users | Citations | Links |
|:-----|:------------|:------|:----------|:------|
| **MoleculeGNN** | Molecular property prediction | 6,000+ | 35+ | [GitHub](https://github.com/compbioai-lab/MoleculeGNN) |
| **DrugCombo** | Drug combination prediction | 1,500+ | 12+ | [GitHub](https://github.com/compbioai-lab/DrugCombo) |
| **BioNetworks** | Network analysis toolkit | 4,000+ | 28+ | [GitHub](https://github.com/compbioai-lab/BioNetworks) |
| **TargetID** | Drug target identification | 2,000+ | 18+ | [GitHub](https://github.com/compbioai-lab/TargetID) |

### Clinical & Precision Medicine

| Tool | Description | Users | Citations | Links |
|:-----|:------------|:------|:----------|:------|
| **ClinicalAI** | Clinical decision support | 500+ | 8+ | [GitHub](https://github.com/compbioai-lab/ClinicalAI) |
| **PatientNet** | Patient similarity networks | 800+ | 10+ | [GitHub](https://github.com/compbioai-lab/PatientNet) |
| **RareVariant** | Rare disease diagnosis | 600+ | 6+ | [GitHub](https://github.com/compbioai-lab/RareVariant) |

{% include section.html %}

## Datasets

We maintain several large-scale datasets for the research community:

### GenomeAtlas 2024
**10TB** | **100 species** | **1M samples**

Comprehensive genomic dataset spanning diverse organisms with consistent processing and annotation.

{%
  include button.html
  text="Access Data"
  link="https://data.compbioai-lab.org/genomeatlas"
  style="button"
%}

### SingleCellDB
**5TB** | **10M cells** | **50 tissues**

Curated single-cell RNA-seq database with standardized processing and cell type annotations.

{%
  include button.html
  text="Browse Database"
  link="https://singlecell.compbioai-lab.org"
  style="button"
%}

### DrugResponseDB
**500GB** | **1,000 drugs** | **500 cell lines**

Drug sensitivity measurements across cancer cell lines with genomic characterization.

{%
  include button.html
  text="Download"
  link="https://data.compbioai-lab.org/drugresponse"
  style="button"
%}

{% include section.html %}

## Web Services

Interactive web applications for biological data analysis:

{%
  include gallery.html

  image1="images/webapps/genomegpt-web.png"
  link1="https://genomegpt.compbioai-lab.org"
  tooltip1="GenomeGPT Web Server"

  image2="images/webapps/variantnet-web.png"
  link2="https://variantnet.compbioai-lab.org"
  tooltip2="VariantNet Web Interface"

  image3="images/webapps/scintegrate-web.png"
  link3="https://scintegrate.compbioai-lab.org"
  tooltip3="scIntegrate Online"

  image4="images/webapps/bionetworks-web.png"
  link4="https://networks.compbioai-lab.org"
  tooltip4="BioNetworks Explorer"
%}

{% include section.html %}

## APIs & Cloud Services

### REST APIs
- **GenomeGPT API**: Genomic sequence analysis
- **VariantNet API**: Variant effect prediction  
- **DrugCombo API**: Drug interaction prediction

[API Documentation](https://api.compbioai-lab.org/docs)

### Cloud Platforms
- **BioCloud**: Scalable analysis platform on AWS
- **CompBio Workbench**: Interactive Jupyter environment
- **DataHub**: Centralized data repository

[Cloud Services Portal](https://cloud.compbioai-lab.org)

{% include section.html %}

## Installation & Usage

### Quick Install

Most tools can be installed via pip or conda:

```bash
# Python packages
pip install genomegpt scintegrate moleculegnn

# Conda packages  
conda install -c compbioai genomegpt scintegrate

# Docker images
docker pull compbioai/genomegpt:latest
```

### System Requirements

- Python 3.8+
- 16GB RAM (32GB recommended)
- GPU recommended for deep learning tools
- Linux/Mac/Windows WSL supported

### Getting Started

1. Check our [documentation hub](https://docs.compbioai-lab.org)
2. Follow interactive [tutorials](https://tutorials.compbioai-lab.org)
3. Join our [user forum](https://forum.compbioai-lab.org)
4. Report issues on [GitHub](https://github.com/compbioai-lab)

{% include section.html %}

## Support & Community

### Documentation
Comprehensive guides, tutorials, and API references
{%
  include button.html
  text="Documentation Hub"
  link="https://docs.compbioai-lab.org"
  style="button"
%}

### Community Forum
Get help, share experiences, and connect with users
{%
  include button.html
  text="Join Forum"
  link="https://forum.compbioai-lab.org"
  style="button"
%}

### Training Workshops
Regular workshops on using our tools
{%
  include button.html
  text="Upcoming Workshops"
  link="workshops"
  style="button"
%}

### Mailing List
Updates on new releases and features
{%
  include button.html
  text="Subscribe"
  link="https://lists.compbioai-lab.org"
  style="button"
%}
{:.center}

{% include section.html %}

## Citation

If you use our tools in your research, please cite the relevant publications:

```bibtex
@article{thompson2024genomegpt,
  title={GenomeGPT: Transformer models for genomic sequence analysis},
  author={Thompson, Alexandra and others},
  journal={Nature Methods},
  year={2024}
}
```

[Full citation list](citations)
