---
title: Join Us
nav:
  order: 5
  tooltip: Open positions and opportunities
---

# Join Our Team

We are always looking for talented, motivated researchers who share our passion for using computational approaches to solve biological problems. We value diversity, creativity, collaboration, and scientific rigor.
{:.center}

{% include section.html %}

## Why Join Us?

### Cutting-Edge Research
- Work on high-impact problems at the intersection of AI and biology
- Access to state-of-the-art computational resources (GPUs, cloud computing)
- Collaborate with world-leading researchers
- Freedom to pursue creative research directions

### Professional Development
- Comprehensive mentorship and career guidance
- Grant writing training and support
- Presentation skills development
- Leadership opportunities
- Industry connections and networking

### Supportive Environment
- Inclusive, diverse, and collaborative culture
- Flexible work arrangements
- Competitive compensation and benefits
- Conference travel support
- Professional development funds

### Work-Life Balance
- Flexible schedules
- Remote work options
- Generous vacation policy
- Parental leave support
- Mental health resources

{% include section.html %}

## Open Positions

### Postdoctoral Researchers

We have multiple postdoc positions available for highly motivated researchers.

**Position 1: Machine Learning for Genomics**
- Develop next-generation deep learning models for genomic analysis
- Lead the GenomeGPT 2.0 development
- Collaborate with experimental partners for validation
- **Requirements**: PhD in CS/CompBio, strong ML background, Python expertise

**Position 2: Single-Cell Multi-Omics**  
- Create novel methods for single-cell data integration
- Work with spatial transcriptomics and imaging data
- Apply methods to atlas-scale projects
- **Requirements**: PhD in CompBio/Statistics, single-cell experience, R/Python skills

**Position 3: Clinical AI**
- Develop AI tools for precision medicine
- Work with electronic health records and genomic data
- Collaborate with clinical partners
- **Requirements**: PhD in relevant field, healthcare data experience, ML expertise

**Salary**: $65,000-75,000 + benefits  
**Duration**: 2-3 years with possibility of extension

{%
  include button.html
  text="Apply for Postdoc Position"
  link="https://careers.university.edu/postdoc-compbioai"
  style="button"
%}

### Graduate Students

We accept PhD students through multiple programs:

#### Computational Biology Program
- Application Deadline: December 1
- Rotations: Fall and Spring
- Funding: Full support for 5 years

#### Computer Science Program
- Application Deadline: December 15
- Direct admission possible
- Teaching assistantship available

#### Bioinformatics Program
- Application Deadline: January 1
- Interdisciplinary training
- Industry internship opportunities

**What we look for:**
- Strong computational/mathematical background
- Programming experience (Python, R, or similar)
- Genuine interest in biological problems
- Previous research experience (preferred)

{%
  include button.html
  text="Graduate Admissions"
  link="https://grad.university.edu/apply"
  style="button"
%}

### Research Software Engineers

**Senior Research Software Engineer**
- Lead development of lab software infrastructure
- Design scalable analysis pipelines
- Manage cloud deployments
- Mentor junior developers
- **Requirements**: BS/MS in CS, 3+ years experience, Python/cloud expertise
- **Salary**: $90,000-120,000

**Bioinformatics Software Developer**
- Develop and maintain analysis tools
- Create user interfaces and documentation
- Support lab members and external users
- **Requirements**: BS in CS/Bioinformatics, Python/R skills
- **Salary**: $70,000-90,000

{%
  include button.html
  text="Apply for Staff Position"
  link="https://careers.university.edu/staff-compbioai"
  style="button"
%}

### Undergraduate Researchers

We offer multiple opportunities for undergraduates:

#### Academic Year Research
- 10-15 hours/week during semester
- Course credit or paid position
- Work directly with graduate student/postdoc mentor
- Present at undergraduate research symposium

#### Summer Research Program
- 10-week full-time paid internship
- $6,000 stipend + housing support
- Structured research project
- Professional development workshops
- Application Deadline: February 1

#### Senior Thesis Projects
- Year-long research project
- Weekly one-on-one mentoring
- Opportunity to co-author publications
- Present at conferences

{%
  include button.html
  text="Undergraduate Application"
  link="https://undergrad.university.edu/research"
  style="button"
%}

{% include section.html %}

## Application Process

### What to Include

1. **Cover Letter** (1-2 pages)
   - Why you're interested in our lab
   - Relevant background and skills
   - Career goals
   - Specific projects/papers of interest

2. **CV/Resume**
   - Education
   - Research experience
   - Publications/presentations
   - Technical skills
   - Awards/honors

3. **Research Statement** (postdocs only, 2-3 pages)
   - Past research accomplishments
   - Future research interests
   - How you'll contribute to the lab

4. **References** (3 letters)
   - Research advisors preferred
   - Submit directly or provide contacts

5. **Code Samples** (optional but encouraged)
   - GitHub profile
   - Example projects
   - Documentation samples

### How to Apply

Email materials to: **jobs@compbioai-lab.org**

Subject line format:
- Postdoc: "Postdoc Application - [Your Name] - [Position]"
- Student: "Graduate Student Interest - [Your Name]"
- Staff: "Staff Application - [Your Name] - [Position]"
- Undergrad: "Undergraduate Research - [Your Name]"

### Timeline

We review applications on a rolling basis:
- **Postdocs**: Year-round
- **Graduate Students**: Follow program deadlines
- **Staff**: As positions open
- **Undergrads**: Fall (Sept), Spring (Jan), Summer (Feb)

### Interview Process

1. **Initial Screen** (30 min video call)
2. **Technical Interview** (1 hour)
3. **Research Presentation** (30 min + questions)
4. **Meet with Lab Members** (informal)
5. **Final Discussion** with PI

{% include section.html %}

## Diversity & Inclusion

We are committed to building a diverse and inclusive research environment. We strongly encourage applications from:
- Women and gender minorities
- Underrepresented racial and ethnic groups
- LGBTQIA+ individuals
- First-generation college students
- Individuals with disabilities
- Veterans

We provide:
- Inclusive mentoring practices
- Family-friendly policies
- Accessibility accommodations
- Connection to university diversity resources
- Support for visa applications (international applicants)

{% include section.html %}

## Rotation Students

### Rotation Projects

We offer diverse rotation projects spanning our research areas:

1. **Deep Learning Project**: Develop neural network for variant interpretation
2. **Single-Cell Project**: Analyze developmental trajectories in organoids
3. **Network Project**: Build drug-target interaction networks
4. **Clinical Project**: Predict treatment response from multi-omics data

### What to Expect

- **Week 1-2**: Literature review and project planning
- **Week 3-8**: Active research and method development
- **Week 9-10**: Analysis, writing, and presentation
- Regular one-on-one meetings with mentor
- Participation in lab meetings and journal club
- Final presentation to the lab

### Past Rotation Outcomes

- 80% of rotation students join the lab
- Average 1 publication from rotation work
- Many continue rotation projects as thesis work

{% include section.html %}

## Testimonials

> "The collaborative environment and cutting-edge research make this the ideal place for computational biology training. The mentorship I've received has been invaluable for my career development."
> 
> **— Michael Johnson, Current PhD Student**

> "As a postdoc in the lab, I had the freedom to pursue ambitious projects while receiving excellent mentorship. The experience prepared me well for my faculty position."
> 
> **— Dr. Sarah Kim, Former Postdoc, Now Assistant Professor at Stanford**

> "The lab's commitment to open science and reproducible research has shaped how I approach all my work. Plus, the team is genuinely fun to work with!"
> 
> **— Wei Zhang, Current Postdoc**

{% include section.html %}

## Frequently Asked Questions

**Q: Do I need a biology background to join the lab?**
A: No! We value diverse backgrounds. Many successful lab members come from CS, math, physics, or engineering.

**Q: Can international students/postdocs apply?**
A: Yes! We sponsor visas and have extensive experience with international researchers.

**Q: Is remote work possible?**
A: We support flexible arrangements. Some positions allow partial or full remote work.

**Q: What computational resources are available?**
A: We have dedicated GPU clusters, cloud computing budgets, and priority access to university HPC.

**Q: Are there opportunities for collaboration?**
A: Absolutely! We encourage collaborations both within the university and with external partners.

{% include section.html %}

## Contact

Questions about positions or the application process?

{%
  include button.html
  type="email"
  text="jobs@compbioai-lab.org"
  link="jobs@compbioai-lab.org"
%}
{:.center}

Or reach out to current lab members - we're happy to chat about our experiences!
