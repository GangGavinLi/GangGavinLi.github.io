---
name: Alexandra Thompson
image: images/team/alexandra-thompson.jpg
role: pi
aliases:
  - A. Thompson
  - A Thompson
  - Alexandra Thompson
  - Thompson A
links:
  home-page: https://alexandrathompson.org
  email: athompson@university.edu
  orcid: 0000-0002-4655-3773
  google-scholar: DqZhOQYAAAAJ
  github: athompson-compbio
  twitter: DrAlexThompson
  linkedin: alexandra-thompson-phd
---

Alexandra Thompson is Professor of Computational Biology and Computer Science, and the founding director of the Computational Biology & AI Lab. She is internationally recognized for her pioneering work in applying machine learning to genomics and her development of widely-used computational tools for biomedical research.

## Education

- **PhD in Computer Science**, MIT (2012)
  - Thesis: "Machine Learning Methods for Genomic Sequence Analysis"
  - Advisor: Prof. David MacArthur
  
- **MPhil in Computational Biology**, University of Cambridge (2008)
  - Churchill Scholar
  
- **BS in Computer Science and Biology**, Stanford University (2006)
  - Summa Cum Laude, Phi Beta Kappa

## Positions

- **2020-present**: Professor, Department of Computational Biology
- **2015-2020**: Associate Professor, Department of Computational Biology  
- **2012-2015**: Assistant Professor, Department of Computer Science
- **2010-2012**: Postdoctoral Fellow, Broad Institute of MIT and Harvard

## Research Interests

Dr. Thompson's research focuses on developing machine learning methods to understand biological systems and improve human health. Key areas include:

- Deep learning for genomic sequence analysis
- Single-cell computational methods
- Network approaches to disease
- AI for drug discovery
- Precision medicine

## Selected Honors and Awards

- 2024: Elected to National Academy of Sciences
- 2023: ISCB Innovator Award
- 2022: MacArthur Fellowship
- 2021: NIH Director's Pioneer Award
- 2020: Sloan Research Fellowship
- 2019: NSF CAREER Award
- 2018: MIT Technology Review 35 Under 35
- 2017: Overton Prize, International Society for Computational Biology
- 2016: Presidential Early Career Award (PECASE)
- 2015: Searle Scholar

## Selected Publications

Dr. Thompson has published over 150 peer-reviewed papers with >10,000 citations (h-index: 65). Selected publications:

1. **Thompson A**, et al. (2024). "Transformer models unlock the regulatory code of the human genome." *Nature Methods*.

2. Liu J, **Thompson A**. (2023). "Deep learning reveals principles of cellular organization." *Cell*.

3. **Thompson A**, Smith K. (2023). "Network-based drug repurposing using AI." *Science*.

4. Chen M, **Thompson A**. (2022). "Single-cell multi-omics reveals disease mechanisms." *Nature*.

5. **Thompson A**. (2021). "The future of AI in biology and medicine." *Nature Reviews Genetics*. (Perspective)

## Teaching

- **CS 585**: Deep Learning for Biology (Fall)
- **BIOL 495**: Computational Genomics (Spring)  
- **CS 290**: Introduction to Bioinformatics (Online)

## Service

### Editorial Boards
- Senior Editor, *Nature Computational Biology*
- Associate Editor, *Cell Systems*
- Editorial Board, *Genome Biology*

### Conference Organization  
- Program Chair, RECOMB 2024
- Co-chair, NeurIPS Computational Biology Workshop 2023
- Organizing Committee, ISMB 2022

### Advisory Roles
- Scientific Advisory Board, Chan Zuckerberg Biohub
- External Advisor, European Bioinformatics Institute
- Consultant, Several biotech companies

## Mentorship

Dr. Thompson has mentored:
- 12 PhD students (8 graduated, 4 current)
- 15 Postdoctoral fellows (10 in faculty positions)
- 25+ Undergraduate researchers
- 8 High school students

Many of her trainees have received prestigious awards and gone on to leadership positions in academia and industry.

## Media Coverage

Dr. Thompson's work has been featured in:
- The New York Times
- Nature News
- Science Magazine
- MIT Technology Review
- The Economist
- NPR Science Friday

## Contact

**Office**: Building 10, Room 500
**Phone**: (617) 555-0100
**Admin Assistant**: Jane Smith (jsmith@university.edu)

**Office Hours**: Thursdays 2-4pm (sign up via calendar link)
**Lab Meetings**: Fridays 10am, Conference Room 10-501
