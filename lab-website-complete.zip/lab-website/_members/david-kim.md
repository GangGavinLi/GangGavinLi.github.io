---
name: David Kim
image: images/team/david-kim.jpg
role: staff
links:
  email: dkim@university.edu
  github: davidkim-dev
  linkedin: david-kim-bioinfo
---

David Kim is the Lead Research Software Engineer for the lab. He oversees our computational infrastructure, develops research software, and ensures our tools are robust and user-friendly.

## Role

David manages:
- High-performance computing infrastructure
- Software development and deployment
- Database management and APIs
- Cloud computing resources
- Open-source tool maintenance

## Background

- **MS in Computer Science**, University of Washington (2018)
- **BS in Bioinformatics**, UC San Diego (2016)

Previous positions:
- Software Engineer, Amazon Web Services (2018-2021)
- Bioinformatics Analyst, Illumina (2016-2018)

## Key Contributions

### Software Development
- Lead developer of 5 major lab software packages
- 10,000+ commits to lab GitHub repositories  
- Maintained tools with 50,000+ users worldwide

### Infrastructure
- Designed and deployed lab's GPU cluster
- Implemented CI/CD pipelines for all projects
- Developed data management systems handling 100TB+ data

### Notable Projects
- **BioCloud**: Cloud platform for biological data analysis
- **CompBio-API**: RESTful API for lab's web services
- **LabFlow**: Workflow management system for reproducible research

## Publications

David has co-authored 15 papers focusing on software and methods:

1. Kim D, Thompson A. (2024). "BioCloud: Scalable cloud computing for genomics." *Bioinformatics*.

2. Kim D, et al. (2023). "Best practices for research software in computational biology." *Nature Methods*.

## Teaching & Mentoring

- Instructor, Annual Software Carpentry Workshop
- Mentor for rotation students and undergraduates
- Developer of lab's onboarding documentation

## Skills

**Languages**: Python, R, JavaScript, Go, Rust
**Frameworks**: PyTorch, TensorFlow, React, Django
**Tools**: Docker, Kubernetes, AWS, GCP, Nextflow
**Databases**: PostgreSQL, MongoDB, Neo4j
