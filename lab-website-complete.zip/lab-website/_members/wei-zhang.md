---
name: Wei Zhang
image: images/team/wei-zhang.jpg
role: postdoc
group: alum
links:
  email: wzhang@university.edu
  orcid: 0000-0003-1234-5678
  google-scholar: abc123XYZ
  github: weizhang-ml
  twitter: WeiZhangPhD
  linkedin: wei-zhang-compbio
---

Wei Zhang is a postdoctoral fellow who joined the lab in 2022 after completing his PhD at UC Berkeley. His research focuses on developing graph neural networks for drug discovery and molecular property prediction.

## Research

Wei's current projects include:
- **MoleculeGNN**: Graph neural networks for molecular property prediction
- **DrugCombo**: Predicting synergistic drug combinations using AI
- **TargetID**: Deep learning for drug target identification

## Background

- **PhD in Computer Science**, UC Berkeley (2022)
  - Advisor: Prof. Jennifer Doudna
  - Thesis: "Graph Neural Networks for Molecular Design"
  
- **MS in Bioinformatics**, Tsinghua University (2017)

- **BS in Computer Science**, Peking University (2015)

## Selected Publications

1. Zhang W, Thompson A. (2024). "Graph neural networks for drug-target interaction prediction." *Nature Machine Intelligence*.

2. Zhang W, et al. (2023). "Deep learning identifies synergistic drug combinations." *Cell Chemical Biology*.

3. Zhang W, Chen L. (2022). "MoleculeNet: A benchmark for molecular machine learning." *Chemical Science*.

## Awards

- 2024: ISMB Best Poster Award
- 2023: Postdoctoral Fellowship, Life Sciences Research Foundation
- 2022: Outstanding Graduate Student Instructor Award, UC Berkeley
- 2021: Facebook AI Research Fellowship

## Software

- [MoleculeGNN](https://github.com/compbioai-lab/MoleculeGNN) - 1000+ stars on GitHub
- [DrugCombo](https://github.com/compbioai-lab/DrugCombo) - Used by 10+ pharma companies
- [TargetID](https://github.com/compbioai-lab/TargetID) - Web server with 5000+ users

## Mentoring

Wei co-mentors 2 graduate students and 1 undergraduate researcher on drug discovery projects.
