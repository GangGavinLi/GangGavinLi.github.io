---
name: Michael Johnson
image: images/team/michael-johnson.jpg
role: phd
links:
  email: mjohnson@university.edu
  github: mjohnson-compbio
  linkedin: michael-johnson-phd
  twitter: MikeJohnsonCS
---

Michael Johnson is a fourth-year PhD student in the Computational Biology program. He develops deep learning architectures for predicting the effects of genetic variants and understanding protein function.

## Research

Michael's thesis work focuses on:
- **ProteinBERT**: Language models for protein sequence analysis
- **VariantNet**: Predicting pathogenic genetic variants
- **FoldPredict**: Deep learning for protein structure prediction

## Education

- **PhD in Computational Biology** (2021-present)
  - University Graduate Fellowship recipient
  
- **BS in Computer Science**, Caltech (2021)
  - Summa Cum Laude
  - Senior thesis: "Neural Networks for Protein Design"

## Publications

1. Johnson M, Thompson A. (2024). "Protein language models predict variant effects." *Nature Genetics* (in press).

2. Johnson M, et al. (2023). "Deep learning for protein functional annotation." *Bioinformatics*.

3. Johnson M, Zhang W. (2023). "Benchmarking variant effect predictors." *Genome Biology*.

## Awards

- 2024: NSF Graduate Research Fellowship
- 2023: Best Student Paper, RECOMB
- 2022: Department Teaching Award
- 2021: Caltech Bioinformatics Prize

## Teaching

- Teaching Assistant:
  - CS 585: Deep Learning for Biology (Fall 2023)
  - BIOL 290: Introduction to Bioinformatics (Spring 2023)

## Service

- Co-President, Computational Biology Student Association
- Organizer, Annual Bioinformatics Bootcamp
- Mentor, Undergraduate research program
