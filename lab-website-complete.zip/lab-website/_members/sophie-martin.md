---
name: Sophie Martin
image: images/team/sophie-martin.jpg
role: postdoc
links:
  email: smartin@university.edu
  orcid: 0000-0002-9876-5432
  google-scholar: def456ABC
  github: sophie-martin
  twitter: SophieMartinPhD
  linkedin: sophie-martin-phd
---

Sophie Martin joined the lab in 2023 after completing her PhD at the University of Oxford. She develops machine learning methods for single-cell multi-omics integration and cellular trajectory inference.

## Research Focus

Sophie's research bridges machine learning and developmental biology:
- **scMultiNet**: Deep learning for single-cell multi-omics
- **CellFate**: Predicting cell differentiation trajectories
- **SpatialCell**: Integrating spatial transcriptomics with imaging

## Education

- **PhD in Computational Biology**, University of Oxford (2023)
  - Wellcome Trust PhD Programme
  - Thesis: "Machine Learning for Single-Cell Genomics"
  
- **MRes in Systems Biology**, Imperial College London (2019)

- **BSc in Mathematics**, University of Edinburgh (2018)
  - First Class Honours

## Key Publications

1. Martin S, Thompson A. (2024). "Multi-modal learning reveals cell state transitions." *Nature Methods*.

2. Martin S, et al. (2023). "Deep learning for spatial transcriptomics." *Nature Biotechnology*.

3. Martin S, Jones R. (2023). "Trajectory inference using neural ODEs." *Cell Systems*.

## Awards & Honors

- 2024: EMBO Postdoctoral Fellowship
- 2023: ISCB Outstanding Student Paper Award
- 2022: Wellcome Trust PhD Prize
- 2021: Best Talk, Single Cell Genomics Conference

## Teaching

Sophie co-teaches the graduate course "Machine Learning for Single-Cell Analysis" and has mentored 3 rotation students.

## Outreach

- Co-organizer, Women in Computational Biology Workshop
- Mentor, Girls Who Code program
- Speaker, Local high school STEM programs
