---
name: Aisha Patel
image: images/team/aisha-patel.jpg
role: phd
links:
  email: apatel@university.edu
  orcid: 0000-0001-7890-1234
  github: aisha-patel
  linkedin: aisha-patel-ml
  website: https://aishapatel.github.io
---

Aisha Patel is a third-year PhD student in Computer Science, co-advised by Dr. Thompson and Prof. Chen in the Medical School. Her research applies deep learning to clinical genomics and precision medicine.

## Research Interests

- Clinical variant interpretation using AI
- Multi-modal learning for patient stratification
- Federated learning for healthcare data
- Explainable AI for medical applications

## Current Projects

- **ClinicalAI**: Interpretable ML for clinical decision support
- **RareVariant**: Identifying pathogenic variants in rare diseases
- **PatientNet**: Patient similarity networks for precision medicine

## Education

- **MS in Machine Learning**, Carnegie Mellon University (2022)
- **BTech in Computer Science**, IIT Bombay (2020)
  - Institute Gold Medal

## Selected Publications

1. Patel A, Thompson A, Chen L. (2024). "Federated learning for clinical genomics." *Nature Medicine* (submitted).

2. Patel A, et al. (2023). "Explainable AI for variant classification." *American Journal of Human Genetics*.

3. Patel A, Johnson M. (2023). "Multi-modal learning in precision oncology." *Cancer Cell*.

## Awards & Fellowships

- 2023: Google PhD Fellowship in Machine Learning
- 2023: ASHG Charles J. Epstein Award (Semifinalist)
- 2022: Women in Machine Learning Scholarship
- 2020: IIT Bombay President's Gold Medal

## Leadership

- Founder, AI for Healthcare Student Group
- Board Member, Women in CS Organization
- Organizer, Annual Health Data Hackathon

## Outreach

- Instructor, AI Summer Camp for High School Students
- Mentor, Women in STEM Mentorship Program
- Speaker, "AI in Medicine" Seminar Series
