---
title: Contact
nav:
  order: 6
  tooltip: Email, address, and location
---

# Contact Us

We welcome inquiries about our research, collaboration opportunities, and positions in the lab. We're located in the heart of the university's biomedical research campus.
{:.center}

{% include section.html %}

## Get in Touch

{%
  include button.html
  type="email"
  text="contact@compbioai-lab.org"
  link="contact@compbioai-lab.org"
%}
{%
  include button.html
  type="phone"
  text="(617) 555-0100"
  link="+1-617-555-0100"
%}
{:.center}

### Specific Inquiries

- **Research Collaborations**: collab@compbioai-lab.org
- **Prospective Students**: students@compbioai-lab.org
- **Postdoc Applications**: postdoc@compbioai-lab.org
- **Software Support**: support@compbioai-lab.org
- **Media Inquiries**: media@compbioai-lab.org

{% include section.html %}

## Visit Us

{%
  include figure.html
  image="images/building.jpg"
  width="100%"
%}

### Physical Address

**Computational Biology & AI Lab**  
Department of Computational Biology  
University Medical Center  
450 Brookline Avenue  
Building CLS, 10th Floor  
Boston, MA 02215  
USA

{%
  include button.html
  type="address"
  tooltip="Our location on Google Maps"
  link="https://maps.google.com/compbioai-lab"
%}
{:.center}

### Mailing Address

**Dr. Alexandra Thompson**  
Computational Biology & AI Lab  
450 Brookline Avenue, CLS-10  
Boston, MA 02215  
USA

{% include section.html %}

## Directions & Parking

### By Public Transit
- **Green Line**: Longwood Medical Area Station (5 min walk)
- **Orange Line**: Ruggles Station (10 min walk)
- **Bus Routes**: 8, 19, 47, CT2 stop nearby
- **Commuter Rail**: Ruggles or Back Bay stations

### By Car
- From I-90: Take Exit 22, follow signs to Longwood Medical Area
- From I-93: Take Exit 26 (Storrow Drive), exit at Fenway/Longwood
- **Visitor Parking**: Garage D ($15/day with validation)
- **Street Parking**: 2-hour meters available on nearby streets

### By Bike
- Blue Bikes stations located at building entrance
- Secure bike storage available for lab members

### Accessibility
- Building is fully wheelchair accessible
- Elevator access to all floors
- Accessible parking in Garage D
- Accessible restrooms on every floor

{% include section.html %}

## Office Hours & Availability

### Professor Thompson's Office Hours
- **Regular Hours**: Thursdays 2:00-4:00 PM (Room CLS-1050)
- **By Appointment**: [Schedule via Calendly](https://calendly.com/athompson)

### Lab Meetings
- **Weekly Lab Meeting**: Fridays 10:00 AM (Conference Room CLS-1020)
- **Journal Club**: Wednesdays 4:00 PM (Seminar Room CLS-1015)
- **Computational Methods Workshop**: Mondays 3:00 PM (Computer Lab CLS-1005)

### Administrative Support
**Jane Smith**, Administrative Assistant  
- Email: jsmith@university.edu
- Phone: (617) 555-0101
- Office: CLS-1001
- Hours: Monday-Friday, 9:00 AM - 5:00 PM

{% include section.html %}

## Seminar Series

We host a weekly Computational Biology Seminar Series featuring leading researchers from around the world.

**When**: Tuesdays, 12:00-1:00 PM  
**Where**: Auditorium CLS-G01  
**Format**: Hybrid (in-person and Zoom)

{%
  include button.html
  text="Upcoming Seminars"
  link="seminars"
  style="button"
%}
{%
  include button.html
  text="Join Mailing List"
  link="https://lists.compbioai-lab.org/seminars"
  style="button"
%}
{:.center}

{% include section.html %}

## Social Media

Follow us for the latest updates:

{%
  include button.html
  type="twitter"
  text="Twitter"
  link="compbioai_lab"
%}
{%
  include button.html
  type="linkedin"
  text="LinkedIn"
  link="compbioai-lab"
%}
{%
  include button.html
  type="youtube"
  text="YouTube"
  link="CompBioAILab"
%}
{%
  include button.html
  type="github"
  text="GitHub"
  link="compbioai-lab"
%}
{:.center}

{% include section.html %}

## Collaboration Map

We collaborate with researchers around the world. Our network includes partnerships with:

- **North America**: Harvard, MIT, Stanford, UCSF, Toronto, McGill
- **Europe**: Cambridge, Oxford, ETH Zurich, Max Planck Institutes
- **Asia**: Tokyo, NUS, IISc, KAIST, Tsinghua
- **Industry**: Google, Microsoft, Genentech, Moderna

{%
  include figure.html
  image="images/collaboration-map.png"
  width="100%"
%}
