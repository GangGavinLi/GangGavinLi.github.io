---
title: Blog
nav:
  order: 4
  tooltip: News, updates, and insights
---

# Blog

Stay updated with the latest news from our lab, including research breakthroughs, new publications, team updates, and insights into computational biology.
{:.center}

{% include section.html %}

## Featured Posts

{% include list.html data="posts" component="post-excerpt" filters="tag: featured" %}

{% include section.html %}

## Recent Posts

{% include search-box.html %}

{% include search-info.html %}

{% include list.html data="posts" component="post-excerpt" %}

{% include section.html %}

## Archive

Browse our posts by category:

{% capture tags %}
{% for post in site.posts %}
  {% for tag in post.tags %}
    {{ tag }}
  {% endfor %}
{% endfor %}
{% endcapture %}

{% include tags.html tags=tags %}

{% include section.html %}

## Subscribe

Never miss an update from our lab:

{%
  include button.html
  text="RSS Feed"
  link="feed.xml"
  icon="fa-solid fa-rss"
  style="button"
%}
{%
  include button.html
  text="Email Newsletter"
  link="https://compbioai-lab.substack.com"
  icon="fa-solid fa-envelope"
  style="button"
%}
{%
  include button.html
  text="Follow on Twitter"
  link="https://twitter.com/compbioai_lab"
  icon="fa-brands fa-twitter"
  style="button"
%}
{:.center}
