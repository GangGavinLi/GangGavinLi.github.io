---
title: Research
nav:
  order: 1
  tooltip: Published works and ongoing projects
---

# Research

Our research program combines cutting-edge machine learning with biological insights to address fundamental questions in biomedicine. We are committed to open science, with all our methods freely available as open-source software.
{:.center}

{% include section.html %}

## Research Areas

### AI for Genomics {#genomics}

We develop deep learning models to understand the language of the genome. Our work spans from predicting the effects of genetic variants to modeling gene regulation and chromatin dynamics.

**Key Projects:**
- **GenomeGPT**: Large language models for genomic sequence analysis
- **VarEffect**: Deep learning for variant effect prediction
- **ChromaNet**: Modeling 3D chromatin organization

**Recent Publications:**
- Nature Methods 2024: "Transformer models for genome-wide regulatory element prediction"
- Cell 2023: "Deep learning reveals the grammar of gene regulation"
- Nature Biotechnology 2023: "Accurate variant effect prediction using protein language models"

### Single-Cell Analysis {#single-cell}

Our lab pioneers computational methods for single-cell multi-omics, developing tools to map cellular heterogeneity and understand cell fate decisions.

**Key Projects:**
- **scIntegrate**: Multi-modal single-cell data integration
- **CellTrajectory**: Inferring developmental trajectories
- **scVelo**: RNA velocity analysis for dynamic processes

**Recent Publications:**
- Nature 2024: "Atlas of human cell states across development and disease"
- Cell Systems 2023: "Integrative analysis of single-cell multi-omics data"
- Nature Methods 2023: "Deep learning for cell type classification"

### Network Medicine {#networks}

We construct and analyze molecular networks to understand disease mechanisms, identify drug targets, and predict treatment responses.

**Key Projects:**
- **BioNetworks**: Comprehensive molecular interaction networks
- **DrugNet**: AI-powered drug repurposing
- **DiseaseMap**: Network-based disease classification

**Recent Publications:**
- Science 2024: "Network-based prediction of drug combinations"
- Nature Medicine 2023: "Molecular networks reveal disease subtypes"
- Cell 2023: "AI-driven target discovery for rare diseases"

{% include section.html %}

## Featured Publications

{% include search-box.html %}

{% include search-info.html %}

{%
  include list.html
  data="citations"
  component="citation"
  style="rich"
%}

{% include section.html %}

## Preprints

{%
  include citation.html
  lookup="doi:10.1101/2024.10.12.345678"
  style="rich"
%}

{%
  include citation.html
  lookup="doi:10.1101/2024.09.15.234567"
  style="rich"
%}

{%
  include citation.html
  lookup="doi:10.1101/2024.08.20.123456"
  style="rich"
%}

{% include section.html %}

## Research Philosophy

### Open Science
All our research outputs are freely available:
- **Open Access**: All papers available through preprint servers
- **Open Source**: All code on GitHub with documentation
- **Open Data**: Processed datasets shared through public repositories
- **Reproducible**: Docker containers and workflows for all analyses

### Collaboration
We believe the best science happens through collaboration:
- Active partnerships with 20+ labs worldwide
- Regular exchange programs with industry partners
- Co-mentorship programs with experimental labs
- Participation in international consortiums

### Translation
Our goal is to translate computational discoveries into clinical impact:
- Partnerships with major medical centers
- Clinical validation of computational predictions
- Development of diagnostic and prognostic tools
- Training clinicians in computational methods

{% include section.html %}

## Research Resources

### Datasets
- **CellAtlas2024**: 10 million cells across 50 tissues
- **GenomeVar**: 100 million annotated genetic variants
- **ProteinNet**: 500,000 protein structures with annotations
- **DrugResponse**: Drug sensitivity data for 1,000 cell lines

### Software Tools
- All tools available at [github.com/compbioai-lab](https://github.com/compbioai-lab)
- Comprehensive documentation and tutorials
- Docker containers for easy deployment
- Cloud-based implementations available

### Computational Resources
- Access to 1000+ GPU cluster
- 10PB storage for biological data
- Cloud computing partnerships
- Dedicated bioinformatics infrastructure

{%
  include button.html
  link="tools"
  text="Explore Our Tools"
  icon="fa-solid fa-toolbox"
  flip=true
  style="button"
%}
{%
  include button.html
  link="https://data.compbioai-lab.org"
  text="Access Datasets"
  icon="fa-solid fa-database"
  flip=true
  style="button"
%}
{:.center}

{% include section.html %}

## Impact Metrics

| Metric | Value |
|:------:|:-----:|
| Total Publications | 150+ |
| Total Citations | 10,000+ |
| h-index | 65 |
| Software Users | 50,000+ |
| Datasets Downloads | 1M+ |
| GitHub Stars | 5,000+ |

{% include section.html %}

## Funding

Our research is generously supported by:

- National Institutes of Health (NIH)
  - R01 GM123456 - "Machine Learning for Genomic Medicine"
  - U54 CA234567 - "AI Center for Cancer Research"
  - R35 GM345678 - "MIRA: Computational Methods for Biomedicine"

- National Science Foundation (NSF)
  - CAREER Award - "Deep Learning for Biological Sequences"
  - BigData Grant - "Scalable ML for Single-Cell Analysis"

- Chan Zuckerberg Initiative
  - Essential Open Source Software Award
  - Single-Cell Biology Program Grant

- Simons Foundation
  - Investigator Award in Mathematical Modeling

- Industry Partners
  - Google Research Award
  - Microsoft AI for Health Grant
  - AWS Cloud Credits Program
